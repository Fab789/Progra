
package com.mycompany.tareaprogramada;


public class Automovil extends Vehiculo {
    
    String marca;
    int año;
    String modelo;
    double tamañoMotor;
    
     Automovil(String marca, int año, String modelo, double tamañoMotor) {
        this.marca = marca;
        this.año = año;
        this.modelo = modelo;
        this.tamañoMotor = tamañoMotor;
    }
    
    
}
