
package com.mycompany.tareaprogramada;


public class Vehiculo {
    int velocidad;
    
    void aumentarVelocidad() {
        velocidad += 10;
        System.out.println("Velocidad aumentada a " + velocidad);
    }
     void disminuirVelocidad() {
        velocidad -= 10;
        System.out.println("Velocidad disminuida a " + velocidad);
    }
     
    void frenar() {
        velocidad = 0;
        System.out.println("Vehículo frenado");
    }
    void encenderAlarma() {
        System.out.println("Alarma encendida. Emitiendo 10 sonidos");
        for (int i = 0; i < 10; i++) {
            System.out.println("Sonido " + (i + 1));
        }
        

    
}
}