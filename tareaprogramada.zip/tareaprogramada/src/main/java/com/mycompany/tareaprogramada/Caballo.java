
package com.mycompany.tareaprogramada;


public class Caballo extends Vehiculo {
    String raza;
    int edad;
    int nivelHambre;
    
    Caballo(String raza, int edad, int nivelHambre) {
        this.raza = raza;
        this.edad = edad;
        this.nivelHambre = nivelHambre;
    }
    
    
}
