
package com.mycompany.tareaprogramada;


public class Usuario {
    String nombre;
    String cedula;
    double dineroTotal;
    Vehiculo vehiculo;
    
     Usuario(String nombre, String cedula, double dineroTotal) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.dineroTotal = dineroTotal;
    }
     
      void comprarVehiculo(Vehiculo vehiculo, double precio) {
        if (dineroTotal >= precio) {
            dineroTotal -= precio;
            this.vehiculo = vehiculo;
            System.out.println("Vehículo comprado con éxito.");
        } else {
            System.out.println("No tienes suficiente dinero para comprar este vehículo.");
        }
    }
     void manejar() {
        if (vehiculo != null) {
            vehiculo.aumentarVelocidad();
            vehiculo.disminuirVelocidad();
            vehiculo.frenar();
            vehiculo.encenderAlarma();
        } else {
            System.out.println("No tienes un vehículo para manejar.");
        }
    } 
    
}
