
package com.mycompany.tareaprogramada;


public class Avion {
    String marca;
    int año;
    double tamaño;
    int numeroMotores;
    
     Avion(String marca, int año, double tamaño, int numeroMotores) {
        this.marca = marca;
        this.año = año;
        this.tamaño = tamaño;
        this.numeroMotores = numeroMotores;
    }
    
}
