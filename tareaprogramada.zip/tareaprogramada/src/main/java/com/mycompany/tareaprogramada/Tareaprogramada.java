

package com.mycompany.tareaprogramada;

import java.util.Scanner;


public class Tareaprogramada {

    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        
         System.out.print("Ingrese nombre del usuario: ");
        String nombreUsuario = scanner.nextLine();

        System.out.print("Ingrese cédula del usuario: ");
        String cedulaUsuario = scanner.nextLine();

        System.out.print("Ingrese dinero total del usuario: ");
        double dineroUsuario = 0;
         try {
            dineroUsuario = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Error: Ingrese un valor numérico para el dinero.");
            System.exit(1);
        }
          Usuario usuario = new Usuario(nombreUsuario, cedulaUsuario, dineroUsuario);
          Automovil automovil = new Automovil("Toyota", 2022, "Corolla", 1.8);
        usuario.comprarVehiculo(automovil, 25000);
        usuario.manejar();
         
    }
     
}
